package Repl167;

class Main {
    final static String myAdress="https://syntaxtechs.com";
    public static void main(String[] args){
        System.out.print("["+myAdress+"]"+"("+myAdress+"/)");
    }
}