package Repl174;

interface MyInterface{
    void method1();
    void method2();
}