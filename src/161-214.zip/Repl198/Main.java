package Repl198;

import java.util.*;
class Main {
    public static void main(String[] args) {
        TreeSet<String> mySet = new TreeSet<>();
        mySet.add("India");
        mySet.add("Australia");
        mySet.add("South Africa");
        mySet.add("India");
        mySet.add("America");
        mySet.add("America");
        System.out.println(mySet);
    }
}