package repl163;

class Child extends Parent{
    void method(){
        System.out.println("Child method");
    }
}