package repl163;

class Main {
    public static void main(String[] args) {
        Parent obj1 = new Parent();
        obj1.method();
        Child obj2 = new Child();
        obj2.method();
    }
}

