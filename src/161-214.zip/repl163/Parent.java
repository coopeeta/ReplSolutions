package repl163;

class Parent{
    void method(){
        System.out.println("Parent method");
    }
}