package repl142;

public class Main {
    public static void main(String[] args) {
        SyntaxTechnologies obj1 = new SyntaxTechnologies();
        obj1.display();
        SyntaxTechnologies obj2 = new SyntaxTechnologies("Syntax", 6, 2020, "07/30/2020");
        obj2.display();
    }
}


