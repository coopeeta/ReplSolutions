package repl145;

class Main {
    public static void main(String[] args) {
        Dog obj = new Dog("Tarzan", 50.0);
        Dog obj1 = new Dog("Lucy", 10.0);
        obj.Display();
        obj1.Display();
    }
}

