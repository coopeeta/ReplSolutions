package repl146;

class Main {
    public static void main(String[] args) {
        Employee obj = new Employee();
        Employee obj1 = new Employee("Joe", "Smith", 12345, "01/01/1970", 35000);
        obj.Display();
        obj1.Display();
    }
}

