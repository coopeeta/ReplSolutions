package repl152;

class Child extends Parent{
    Child(String city){
        super(city);
    }
}