package repl152;

class Main {
    public static void main(String[] args) {
        Child obj = new Child("Vienna");
    }
}

