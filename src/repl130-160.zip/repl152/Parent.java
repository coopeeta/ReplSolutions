package repl152;

class Parent{
    Parent(){
        System.out.println("Parent Constructor");
    }
    Parent(String city){
        System.out.println(city);
    }
}
