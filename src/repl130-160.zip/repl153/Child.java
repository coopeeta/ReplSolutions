package repl153;

class Child extends Parent {
    Child() {
        super();
    }
}