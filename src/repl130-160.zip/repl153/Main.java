package repl153;

class Main {
    public static void main(String[] args) {
        new Child();
    }
}

