package repl153;

class Parent {
    Parent() {
        System.out.println("This is Parent constructor");
    }

}