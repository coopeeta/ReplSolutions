package repl155;

class A{
    A(){
        System.out.println("I");
    }
}
class B extends A {
    B(){
        System.out.println("am");
    }
}
class C extends B{
    C(){
        System.out.println("a tester");
    }
}
