package repl155;

class Main {
    public static void main(String[] args) {
        C obj = new C();
    }
}

